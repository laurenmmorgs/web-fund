function logout(element) {
    element.innerText = "Logout";
}
function like(element) {
    element.alert
}
function hide(element) {
    element.remove();
}